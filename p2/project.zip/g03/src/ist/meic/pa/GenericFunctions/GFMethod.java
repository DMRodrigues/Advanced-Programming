package ist.meic.pa.GenericFunctions;

public class GFMethod {}
